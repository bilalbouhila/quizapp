from flask import Flask, render_template, request, session, redirect, url_for
from google.cloud import storage
import pandas as pd
import random
import json
import os
import secrets

    
app = Flask(__name__)
#app.config['SECRET_KEY'] = '35bd088e587340fe46fd57b1a94647ef'  # replace with your own secret key
app.config['SECRET_KEY'] = secrets.token_hex(32)
def load_data():
    df = pd.read_csv('questions.csv', sep=';')
    questions_list = df.to_dict('records')
    return questions_list
questions = load_data()

@app.route('/start')
def start():
    session.clear()  # This will clear the session
    session['questions'] = load_data()  # Reload the questions data
    return redirect(url_for(home, questions=questions))  # Redirect to the first question
@app.route('/is-question-ready')
def is_question_ready():
    # Replace the below condition with your actual condition to check if question is ready
    if 'question' in session:
        return {"status": "ready"}
    else:
        return {"status": "not ready"}


@app.route('/', methods=['GET', 'POST'])
def home():

    if request.method == 'POST':
        num_questions_str = request.form.get('num_questions')
        mode = request.form.get('mode')  # get the mode
        session['questions'] = questions
        if mode == 'exam':
            # Exam mode: shuffle the questions and select a subset
            random.shuffle(questions)
            if not num_questions_str:
                session['questions'] = questions
            else:
                num_questions = int(num_questions_str)
                if num_questions > len(questions):
                    num_questions = len(questions)
                session['questions'] = random.sample(questions, num_questions)
        elif mode == 'training':
            # Training mode: select a range of questions without shuffling
            start_range_str = request.form.get('start_range')
            start_range = int(start_range_str) - 1 if start_range_str else 0  # if the field is left blank, we start from the first question (0 index)
            end_range = start_range + int(num_questions_str) if num_questions_str else len(questions)  # calculate the end range based on the number of questions, or use the end of the list if no number is provided
            session['questions'] = questions[start_range:end_range]  # select the range of questions
        # delete wrong_answers.json file if it exists
        if os.path.exists('wrong_answers.json'):
            os.remove('wrong_answers.json')

        return redirect(url_for('quiz', question_number=0))

    return render_template('index.html', questions=questions)



@app.route('/question/<int:question_number>', methods=['GET', 'POST'])
def quiz(question_number):

    # Check if 'questions' is in the session
    if 'questions' not in session:
        # If not, redirect to the main page (or any page you want)
        return redirect(url_for('home'))

    question = session['questions'][question_number]
    question['Answers'] = [question['Answer1'], question['Answer2'], question['Answer3'], question['Answer4'], question['Answer5'], question['Answer6']]
    question['Answers'] = [answer for answer in question['Answers'] if pd.notna(answer)]  # remove empty answers

    if request.method == 'POST':
        # User submitted answer, store in session
        answer = request.form.getlist('answer')
        session[str(question_number)] = answer

        # Go to correction page
        return redirect(url_for('correction', question_number=question_number))

    return render_template('quiz.html', question=question, question_number=question_number, questions=session['questions'])


@app.route('/correction/<int:question_number>', methods=['GET', 'POST'])
def correction(question_number):
    question = session['questions'][question_number]
    user_answer = session.get(str(question_number), [])
    correct_answer = str(question['Correct']).split('|')


    if request.method == 'POST':
        # Write all answers to the file
        with open('wrong_answers.json', 'a') as f:
            json.dump({
                'question': question['Question'],
                'user_answer': user_answer,  # store as list
                'correct_answer': correct_answer,  # store as list
                'Explanation' : question['Explanation'],
                'All options' : question['Answers']   # Write all answer options to the file
            }, f)
            f.write('\n')

        if question_number < len(session['questions']) - 1:
            return redirect(url_for('quiz', question_number=question_number + 1))
        else:
            # All questions answered, calculate score and display results
            score = 0
            answers = []
            with open('wrong_answers.json', 'r') as f:
                for line in f:
                    answer = json.loads(line)
                    answers.append(answer)
            for i in range(len(session['questions'])):
                user_answer = session.get(str(i), [])
                correct_answer = session['questions'][i]['Correct'].split('|')
                if set(user_answer) == set(correct_answer):
                    score += 1
            percent = (score / len(session['questions'])) * 100
            return render_template('results.html', score=score, total=len(session['questions']), percent=percent, answers=answers)
    return render_template('correction.html', question=question, user_answer=user_answer, correct_answer=correct_answer)


if __name__ == '__main__':
    app.run(debug=True)
