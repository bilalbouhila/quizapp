import pandas as pd

# Read the csv file
df = pd.read_csv('questions.csv', sep=';', error_bad_lines=False)

# Checking if the necessary columns exist
required_columns = ['Question', 'NumAnswers', 'Answer1', 'Answer2', 'Answer3', 
                    'Answer4', 'Answer5', 'Answer6', 'Correct', 'Explanation']
if not all(column in df.columns for column in required_columns):
    print('The CSV file does not match the expected schema.')
else:
    # Filter rows where 'Correct' and 'Explanation' fields are empty
    filtered_df = df[df['Correct'].isna() & df['Explanation'].isna()]
    
    # If there are no such rows
    if filtered_df.empty:
        print('There are no lines where both Correct and Explanation fields are empty.')
    else:
        # Print lines where 'Correct' and 'Explanation' fields are empty
        print(filtered_df)
